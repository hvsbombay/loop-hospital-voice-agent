document.addEventListener('DOMContentLoaded', function () {
  if (document.getElementById('setupForm')) {
    setupPage();
  } else if (document.getElementById('matchTitle')) {
    liveMatchPage();
  } else if (document.getElementsByClassName('scorecard-container').length > 0) {
    scorecardPage();
  } else if (document.getElementById('resultText')) {
    summaryPage();
  }
});

// ------------------ Setup Page Logic ------------------
function setupPage() {
  document.getElementById('setupForm').addEventListener('submit', function (event) {
    event.preventDefault();
    const team1 = document.getElementById('team1').value.trim();
    const team2 = document.getElementById('team2').value.trim();
    const tossWinner = document.getElementById('tossWinner').value;
    const tossDecision = document.getElementById('tossDecision').value;

    let matchData = {
      team1: team1,
      team2: team2,
      tossWinner: tossWinner === 'team1' ? team1 : team2,
      tossDecision: tossDecision,
      innings: 1,
      score: 0,
      score2inning: 0,
      wickets: 0,
      wickets2inning: 0,
      balls: 0,
      balls2inning: 0,
      currentBatter: { name: '', runs: 0, balls: 0, fours: 0, sixes: 0 },
      nonStrikeBatter: { name: '', runs: 0, balls: 0, fours: 0, sixes: 0 },
      currentBowler: { name: '', balls: 0, runs: 0, wickets: 0, maidens: 0, lastOverRuns: 0 },
      battingTeam: '',
      bowlingTeam: '',
      battingTeam2: '',
      bowlingTeam2: '',
      batters: [],
      bowlers: [],
      batters2: [],
      bowlers2: []
    };

    while (!matchData.currentBatter.name) {
      matchData.currentBatter.name = prompt("Enter the striker's name:");
    }

    while (!matchData.nonStrikeBatter.name) {
      matchData.nonStrikeBatter.name = prompt("Enter the non-striker's name:");
    }

    while (!matchData.currentBowler.name) {
      matchData.currentBowler.name = prompt("Enter the first bowler's name:");
    }

    matchData.batters.push({ ...matchData.currentBatter });
    matchData.batters.push({ ...matchData.nonStrikeBatter });
    matchData.bowlers.push({ ...matchData.currentBowler });

    localStorage.setItem('matchData', JSON.stringify(matchData));
    window.location.href = 'live.html';
  });
}

// ------------------ Live Match Page Logic ------------------
function liveMatchPage() {
  let matchData = JSON.parse(localStorage.getItem('matchData'));
  if (!matchData) {
    alert("No match data found. Please set up a match first.");
    window.location.href = 'setup.html';
    return;
  }

  setBattingBowlingTeam(matchData);
  updateLive(matchData);

  const runBtn = document.querySelectorAll('.runBtn');
  runBtn.forEach(btn => {
    btn.addEventListener('click', function () {
      let runs = this.getAttribute('data-run');
      if (runs === 'Wicket') {
        getout(matchData);
      } else {
        increaseRuns(matchData, parseInt(runs));
      }
    });
  });

  function getInningContext(matchData) {
    const isFirst = matchData.innings === 1;
    return {
      scoreNow: isFirst ? 'score' : 'score2inning',
      ballsNow: isFirst ? 'balls' : 'balls2inning',
      wicketsNow: isFirst ? 'wickets' : 'wickets2inning',
      battersNow: isFirst ? 'batters' : 'batters2',
      bowlersNow: isFirst ? 'bowlers' : 'bowlers2',
    };
  }

  function updateBatterStats(batterList, batter, runs) {
    batter.runs += runs;
    batter.balls++;
    if (runs === 4) batter.fours++;
    if (runs === 6) batter.sixes++;

    const index = batterList.findIndex(b => b.name === batter.name);
    if (index >= 0) {
      batterList[index] = { ...batter };
    } else {
      batterList.push({ ...batter });
    }
  }

  function updateBowlerStats(bowlerList, bowler, runs, isWicket = false) {
    bowler.runs += runs;
    bowler.balls++;
    if (isWicket) bowler.wickets++;

    if (bowler.balls % 6 === 0) {
      const runsThisOver = bowler.runs - (bowler.lastOverRuns || 0);
      if (runsThisOver === 0) {
        bowler.maidens = (bowler.maidens || 0) + 1;
      }
      bowler.lastOverRuns = bowler.runs;
    }

    const index = bowlerList.findIndex(b => b.name === bowler.name);
    if (index >= 0) {
      bowlerList[index] = { ...bowler };
    } else {
      bowlerList.push({ ...bowler });
    }
  }

  function increaseRuns(matchData, runs) {
    const inningData = getInningContext(matchData);
  
    matchData[inningData.scoreNow] += runs;
    matchData[inningData.ballsNow]++;
  
    updateBatterStats(matchData[inningData.battersNow], matchData.currentBatter, runs);
    updateBowlerStats(matchData[inningData.bowlersNow], matchData.currentBowler, runs);
  
    if (runs % 2 === 1) {
      [matchData.currentBatter, matchData.nonStrikeBatter] = [matchData.nonStrikeBatter, matchData.currentBatter];
    }
  
    const overComplete = matchData[inningData.ballsNow] % 6 === 0;
    const isFirstInningsEnd = matchData.innings === 1 && matchData.balls >= 12;
    const isSecondInningsEnd = matchData.innings === 2 && matchData.balls2inning >= 12;
  
    if (overComplete && !isFirstInningsEnd && !isSecondInningsEnd) {
      [matchData.currentBatter, matchData.nonStrikeBatter] = [matchData.nonStrikeBatter, matchData.currentBatter];
  
      const nextBowlerName = prompt("Enter next bowler name:");
      if (nextBowlerName) {
        matchData.currentBowler = {
          name: nextBowlerName, balls: 0, runs: 0, wickets: 0, maidens: 0, lastOverRuns: 0
        };
      }
    }
  
    if (isFirstInningsEnd) {
      startSecondInnings(matchData);
    } else if (isSecondInningsEnd) {
      endMatch(matchData);
    } else {
      localStorage.setItem('matchData', JSON.stringify(matchData));
      updateLive(matchData);
    }
  }
  

  function getout(matchData) {
    const inningData = getInningContext(matchData);
    matchData[inningData.wicketsNow]++;
    matchData[inningData.ballsNow]++;

    updateBatterStats(matchData[inningData.battersNow], matchData.currentBatter, 0);
    updateBowlerStats(matchData[inningData.bowlersNow], matchData.currentBowler, 0, true);

    const nextBatterName = prompt("Enter next batter's name:");
    matchData.currentBatter = {
      name: nextBatterName,
      runs: 0,
      balls: 0,
      fours: 0,
      sixes: 0
    };

    localStorage.setItem('matchData', JSON.stringify(matchData));
    updateLive(matchData);
  }

  function startSecondInnings(matchData) {
    matchData.innings = 2;
    matchData.balls2inning = 0;
    matchData.wickets2inning = 0;
    matchData.score2inning = 0;

    setBattingBowlingTeam(matchData);

    const bowlerName = prompt("Enter bowler name for 2nd inning:");
    matchData.currentBowler = {
      name: bowlerName, balls: 0, runs: 0, wickets: 0, maidens: 0, lastOverRuns: 0
    };

    const striker = prompt("Enter striker batter name:");
    const nonStriker = prompt("Enter non-striker batter name:");

    matchData.currentBatter = {
      name: striker, runs: 0, balls: 0, fours: 0, sixes: 0
    };
    matchData.nonStrikeBatter = {
      name: nonStriker, runs: 0, balls: 0, fours: 0, sixes: 0
    };

    matchData.batters2 = [matchData.currentBatter, matchData.nonStrikeBatter];
    matchData.bowlers2 = [matchData.currentBowler];

    localStorage.setItem('matchData', JSON.stringify(matchData));
    updateLive(matchData);
  }

  function endMatch(matchData) {
    alert("Match Over!");
    localStorage.setItem('matchData', JSON.stringify(matchData));
    window.location.href = 'summary.html';
  }

  function setBattingBowlingTeam(matchData) {
    if (matchData.tossWinner === matchData.team1) {
      matchData.battingTeam = matchData.tossDecision === 'bat' ? matchData.team1 : matchData.team2;
      matchData.bowlingTeam = matchData.tossDecision === 'bat' ? matchData.team2 : matchData.team1;
    } else {
      matchData.battingTeam = matchData.tossDecision === 'bat' ? matchData.team2 : matchData.team1;
      matchData.bowlingTeam = matchData.tossDecision === 'bat' ? matchData.team1 : matchData.team2;
    }
    matchData.battingTeam2 = matchData.bowlingTeam;
    matchData.bowlingTeam2 = matchData.battingTeam;
  }
}

function updateLive(matchData) {
  const scoreDisplay = document.getElementById('scoreDisplay');
  const isFirstInnings = matchData.innings === 1;

  const currentScore = isFirstInnings ? matchData.score : matchData.score2inning;
  const currentBalls = isFirstInnings ? matchData.balls : matchData.balls2inning;
  const currentWickets = isFirstInnings ? matchData.wickets : matchData.wickets2inning;

  const overs = `${Math.floor(currentBalls / 6)}.${currentBalls % 6}`;
  const CRR = currentBalls ? ((currentScore * 6) / currentBalls).toFixed(2) : "0.00";

  let RRR = "0.00";
  if (!isFirstInnings && currentBalls < 12) {
    const remainingBalls = 12 - currentBalls;
    const runsRequired = (matchData.score + 1) - matchData.score2inning;
    RRR = ((runsRequired * 6) / remainingBalls).toFixed(2);
  }

  if (isFirstInnings) {
    scoreDisplay.innerHTML = `${matchData.battingTeam} ${matchData.score}/${matchData.wickets} (${overs}) vs ${matchData.bowlingTeam}`;
  } else {
    const firstInningsOvers = `${Math.floor(matchData.balls / 6)}.${matchData.balls % 6}`;
    scoreDisplay.innerHTML = `${matchData.battingTeam2} ${matchData.score2inning}/${matchData.wickets2inning} (${overs}) vs ${matchData.battingTeam} ${matchData.score}/${matchData.wickets} (${firstInningsOvers})<br>
                              Target: ${matchData.score + 1} | CRR: ${CRR} | RRR: ${RRR}`;
  }

  // Batter Info
  const updateBatterUI = (batter, prefix) => {
    document.getElementById(`${prefix}Name`).innerText = batter.name;
    document.getElementById(`${prefix}Runs`).innerText = batter.runs;
    document.getElementById(`${prefix}Balls`).innerText = batter.balls;
    document.getElementById(`${prefix}Fours`).innerText = batter.fours;
    document.getElementById(`${prefix}Sixes`).innerText = batter.sixes;
    document.getElementById(`${prefix}StrikeRate`).innerText = batter.balls ? ((batter.runs / batter.balls) * 100).toFixed(2) : "0.00";
  };

  updateBatterUI(matchData.currentBatter, 'strikeBatter');
  updateBatterUI(matchData.nonStrikeBatter, 'nonStrikeBatter');

  // Bowler Info
  const bowler = matchData.currentBowler;
  const bowlerOvers = `${Math.floor(bowler.balls / 6)}.${bowler.balls % 6}`;
  const bowlerEco = bowler.balls ? (bowler.runs / (bowler.balls / 6)).toFixed(2) : "0.00";

  document.getElementById('bowlerInfo').innerHTML = 
    `<strong>${bowler.name}</strong><br>
    Overs: ${bowlerOvers}<br>
    Runs: ${bowler.runs}<br>
    Maidens: ${bowler.maidens}<br>
    Wickets: ${bowler.wickets}<br>
    Economy: ${bowlerEco}`;
}

// ------------------ Scorecard Page Logic ------------------
function scorecardPage() {
  const matchData = JSON.parse(localStorage.getItem('matchData'));
  if (!matchData) {
    alert("No match data found. Please set up a match first.");
    window.location.href = 'setup.html';
    return;
  }

  document.querySelector('h1').innerText = `${matchData.team1} vs ${matchData.team2}`;
  document.querySelector('h2').innerText = `Toss: ${matchData.tossWinner} chose to ${matchData.tossDecision}`;

  const battingTableBody = document.querySelector('#battingTable tbody');
  const bowlingTableBody = document.querySelector('#bowlingTable tbody');
  
  battingTableBody.innerHTML = '';
  bowlingTableBody.innerHTML = '';

  // First Innings
  const isFirstInningOngoing = matchData.innings === 1;
  addInningScorecard(
    battingTableBody, 
    bowlingTableBody, 
    matchData.battingTeam, 
    matchData.batters, 
    matchData.bowlers, 
    matchData.score, 
    matchData.wickets,
    isFirstInningOngoing ? matchData.currentBatter : null,
    isFirstInningOngoing ? matchData.nonStrikeBatter : null,
    isFirstInningOngoing ? matchData.currentBowler : null,
    1,
    isFirstInningOngoing
  );

  // Second Innings if played
  if (matchData.innings === 2) {
    const isSecondInningCompleted = matchData.balls2inning >= 12 || matchData.wickets2inning >= 10;
    addInningScorecard(
      battingTableBody, 
      bowlingTableBody, 
      matchData.battingTeam2, 
      matchData.batters2, 
      matchData.bowlers2, 
      matchData.score2inning, 
      matchData.wickets2inning,
      !isSecondInningCompleted ? matchData.currentBatter : null,
      !isSecondInningCompleted ? matchData.nonStrikeBatter : null,
      !isSecondInningCompleted ? matchData.currentBowler : null,
      2,
      !isSecondInningCompleted
    );
  }
}

function addInningScorecard(battingBody, bowlingBody, teamName, batters, bowlers, score, wickets, currentBatter, nonStrikeBatter, currentBowler, inningNumber, isCurrentInning) {
  let displayBatters = [...batters];
  let displayBowlers = [...bowlers];

  if (isCurrentInning) {
    if (currentBatter && !displayBatters.some(b => b.name === currentBatter.name)) {
      displayBatters.push({...currentBatter});
    }
    if (nonStrikeBatter && !displayBatters.some(b => b.name === nonStrikeBatter.name)) {
      displayBatters.push({...nonStrikeBatter});
    }
  }

  const battingHeader = document.createElement('tr');
  battingHeader.innerHTML = `<th colspan="6">${teamName} - ${inningNumber}${inningNumber === 1 ? 'st' : 'nd'} Innings (${score}/${wickets})</th>`;
  battingBody.appendChild(battingHeader);

  displayBatters.forEach(batter => {
    const isNotOut = isCurrentInning && (batter.name === (currentBatter?.name || '') || batter.name === (nonStrikeBatter?.name || ''));
    const tr = document.createElement('tr');
    tr.innerHTML = 
      `<td>${batter.name}${isNotOut ? ' *' : ''}</td>
      <td>${batter.runs}</td>
      <td>${batter.balls}</td>
      <td>${batter.fours}</td>
      <td>${batter.sixes}</td>
      <td>${batter.balls ? ((batter.runs / batter.balls) * 100).toFixed(2) : "0.00"}</td>`;
    battingBody.appendChild(tr);
  });

  if (isCurrentInning && currentBowler && !displayBowlers.some(b => b.name === currentBowler.name)) {
    displayBowlers.push({...currentBowler});
  }

  const bowlingHeader = document.createElement('tr');
  bowlingHeader.innerHTML = `<th colspan="7">${inningNumber}${inningNumber === 1 ? 'st' : 'nd'} Innings Bowling</th>`;
  bowlingBody.appendChild(bowlingHeader);

  displayBowlers.forEach(bowler => {
    const tr = document.createElement('tr');
    const overs = `${Math.floor(bowler.balls / 6)}.${bowler.balls % 6}`;
    const economy = bowler.balls ? (bowler.runs / (bowler.balls / 6)).toFixed(2) : "0.00";
    
    tr.innerHTML = 
    `<td>${bowler.name}</td>
    <td>${overs}</td>
    <td>${bowler.maidens}</td>
    <td>${bowler.runs}</td>
    <td>${bowler.wickets}</td>
    <td>${economy}</td>`;
    bowlingBody.appendChild(tr);
  });
}

function goBackToLive() {
  window.location.href = 'live.html';
}

// ------------------ Summary Page Logic ------------------
function summaryPage() {
  const matchData = JSON.parse(localStorage.getItem('matchData'));
  const resultText = document.getElementById('resultText');

  if (!matchData) {
    resultText.innerText = "Match data not found!";
    return;
  }

  const team1 = matchData.team1;
  const team2 = matchData.team2;

  const score1 = matchData.score; // 1st innings score
  const wickets1 = matchData.wickets;
  const score2 = matchData.score2inning; // 2nd innings score
  const wickets2 = matchData.wickets2inning;
  const balls2 = matchData.balls2inning;

  if (score2 > score1) {
    const ballsLeft = 12 - balls2;
    const wicketsLeft = 2 - wickets2;
    resultText.innerText = `${matchData.battingTeam2} wins by ${wicketsLeft} wicket(s) with ${ballsLeft} ball(s) remaining!`;
  } else if (score2 < score1) {
    const margin = score1 - score2;
    resultText.innerText = `${matchData.battingTeam} wins by ${margin} run(s)!`;
  } else {
    resultText.innerText = "Match tied!";
  }
}

function resetMatch() {
  localStorage.removeItem('matchData');
  window.location.href = 'setup.html';
}